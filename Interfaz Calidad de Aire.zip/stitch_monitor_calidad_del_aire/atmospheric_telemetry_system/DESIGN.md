---
name: Atmospheric Telemetry System
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#89ceff'
  on-secondary: '#00344d'
  secondary-container: '#00a2e6'
  on-secondary-container: '#00344e'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#e29100'
  on-tertiary-container: '#523200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#c9e6ff'
  secondary-fixed-dim: '#89ceff'
  on-secondary-fixed: '#001e2f'
  on-secondary-fixed-variant: '#004c6e'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  metric-display:
    fontFamily: JetBrains Mono
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.03em
  metric-display-mobile:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.02em
  metric-compact:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  telemetry-unit:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
  label-caps:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.25rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

### Personality & Ethos
This design system embodies precise environmental instrumentation, real-time diagnostic command, and industrial reliability. Designed for engineers, plant supervisors, and environmental compliance officers, the interface communicates calm authority under operational stress. It eliminates decorative noise in favor of high-density telemetry, clear status visibility, and uncompromised legibility across varying ambient light conditions (from control room video walls to field tablets under direct sunlight).

### Aesthetic Direction: Modern Industrial Telemetry & Utilitarian Precision
The visual language combines **Modern Utilitarianism** with **Tonal Layering**:
- **Structured Precision**: High-density layouts, micro-borders, and disciplined alignments inspired by physical SCADA control panels and aerospace telemetry consoles.
- **Intentional Contrast**: A deep slate foundation paired with luminescent functional accents ensures status signals (Óptimo, Moderado, Crítico, Inactivo) are immediately distinguishable within peripheral vision.
- **Clarity Over Embellishment**: Surfaces rely on calibrated dark-slate neutral tiers rather than decorative blurs, preserving hardware rendering performance during continuous real-time data streaming (WebSocket/MQTT feeds).
- **Localization Rigor**: Built natively with Spanish technical taxonomy (*Material Particulado*, *Índice de Calidad del Aire*, *Monóxido de Carbono*, *Falla de Sensor*), engineered to accommodate extended character lengths without breaking layout balance.

## Colors

### Palette Architecture
The palette is built strictly around operational safety standards and diagnostic clarity in industrial continuous-monitoring workflows.

- **Primary (`#10B981` / Emerald)**: Designates nominal performance, optimal thresholds, and compliant operational states (*Estado: Óptimo / Conforme*). Used sparingly on interactive triggers to prevent confusion with status lights.
- **Secondary (`#0EA5E9` / Sky Blue)**: Denotes system connectivity, telemetry feeds, active synchronization, and informational readouts (*Conectado / Transmitiendo*).
- **Tertiary (`#F59E0B` / Amber)**: Alerts operators to elevated pollutant levels, sensor drift warnings, or approaching threshold limits (*Alerta / Moderado*).
- **Status Critical (`#F43F5E` / Rose)**: Urgent intervention required; toxic gas threshold breach, sensor hardware failure, or telemetry drop (*Crítico / Falla de Enlace*).
- **Status Neutral / Inactive (`#64748B` / Slate Grey)**: Powered-down nodes, scheduled maintenance states, or uncalibrated probes (*Inactivo / Desconectado*).
- **Neutral Canvas (`#0F172A` to `#020617` / Deep Slate)**: Deep, anti-reflective base background preventing eye fatigue during continuous 24/7 monitoring.

### Functional Status Rules
1. **Never use color alone** to indicate critical state transitions; always pair status color with explicit icons and localized semantic labels (e.g., `[●] Crítico: PM2.5 > 150 µg/m³`).
2. **Surface Hierarchy**:
   - `surface-base`: `#0B1120` (Root canvas)
   - `surface-card`: `#131E32` (Primary metric containers & telemetry cards)
   - `surface-elevated`: `#1E293B` (Dropdowns, modals, and hover states)
   - `surface-subtle`: `#1E293B4D` (Card header bands and table striping)
3. **Borders & Dividers**: High-precision `#334155` (hairline `1px`) to visually compartmentalize multi-sensor grids without visual weight.

## Typography

### Structural Concept
The typographic hierarchy is dual-engine: **Inter** powers natural-language scanning, navigation, and structural headings, while **JetBrains Mono** drives all numerical readouts, timestamps, coordinates, and telemetry metrics.

### Tactical Implementation Guidelines
- **Tabular Alignment**: All sensor values (`µg/m³`, `ppm`, `ppb`, `°C`, `hPa`) must use fixed-width figures via `JetBrains Mono` to eliminate UI jitter during live polling updates.
- **Metric Formatting**: Display figures with distinct scale separation between value and unit. The value inherits `metric-display` (`#F8FAFC`), while the engineering unit inherits `telemetry-unit` (`#94A3B8`) aligned baseline or superscript.
- **Labeling in Technical Spanish**: Utilize `label-caps` for operational metadata headers (e.g., `ÚLTIMA LECTURA`, `PRESIÓN BAROMÉTRICA`, `CONCENTRACIÓN MEDIA`). All uppercase acronyms (`ICA`, `CO2`, `NO2`, `SO2`, `COV`) maintain neutral tracking without condensed distortion.

## Layout & Spacing

### System Architecture
The platform is designed around a **fluid 12-column telemetry grid** capable of condensing into 8 columns on tablet and 4 columns on ruggedized mobile handsets. Density is kept intentionally high to avoid paging during incident triage.

### Breakpoint Matrix
- **Mobile (< 768px)**: 4 columns. Gutter: `1rem`, Outer margin: `1rem`. Sensor cards stack into full-width compact lists. Sparklines shift from horizontal sidecar to embedded backgrounds behind telemetry metrics.
- **Tablet (768px – 1199px)**: 8 columns. Gutter: `1rem`, Outer margin: `1.5rem`. KPI widgets snap to 4-column spans (2 per row); map view stacks above sensor stream.
- **Desktop (≥ 1200px)**: 12 columns. Gutter: `1.25rem`, Outer margin: `2rem`. Modular dashboard layouts: 3-column sensor KPI cards (4 per row), 8-column historical telemetry charts flanked by a 4-column active alert panel.

### Spacing Principles
- Component internals conform to a compact 4px base step (`space-xs` = 4px, `space-sm` = 8px, `space-md` = 12px, `space-lg` = 16px, `space-xl` = 24px).
- Vertical margins between stacked diagnostic rows must match horizontal column gutters to preserve a disciplined matrix appearance.

## Elevation & Depth

### Depth Model: Tonal Strata & Low-Contrast Borders
Shadows are minimized in this design system to optimize GPU rendering for continuous real-time charts and spatial map overlays. Depth is achieved via **tonal elevation tiers** paired with **crisp low-contrast outlines**:

- **Tier 0 (Root Canvas / Viewport)**: `#0B1120`. Deepest layer, hosts global status bar and geographic GIS air-quality maps.
- **Tier 1 (Surface Containers & Sensor Panels)**: `#131E32`. Border: `1px solid #1E293B`. Houses metric readouts, sparkline charts, and operational controls.
- **Tier 2 (Elevated Panels & Flyouts)**: `#1E293B`. Border: `1px solid #334155`. Used for device detail drawouts, active incident modals, and filter panels.
- **Tier 3 (Popovers, Tooltips & Live Alerts)**: `#334155`. Border: `1px solid #475569`. Soft ambient occlusion shadow (`0 8px 24px -4px rgba(0, 0, 0, 0.45)`) applied only to floating cursor tooltips over telemetry graphs.

### Status Glowing Effects
Critical and Alert states do not use heavy fill overlays. Instead, they leverage subtle edge illumination (`1px solid #F43F5E` with an optional ambient inner glow: `inset 0 0 12px rgba(244, 63, 94, 0.08)`), directing attention instantly without obscuring secondary text data.

## Shapes

### Form Geometry: Soft Precision
A unified roundedness level of `1` (Soft: `4px` base radius, `8px` container radius) is applied across the entire component library. This maintains a sharp, technical aesthetic reminiscent of physical diagnostic instruments while eliminating harsh corner friction.

### Token Application
- **Base (0.25rem / 4px)**: Status badges, action buttons, input fields, sparkline cursor markers, table row containers.
- **Container / `rounded-lg` (0.5rem / 8px)**: Sensor cards, telemetry chart cards, modal frames, GIS map containers.
- **Segmented / `rounded-xl` (0.75rem / 12px)**: Dashboard hero header cards and multi-variable analytics panels.
- **Fully Rounded (Pill / 9999px)**: Strictly reserved for pulsating live sensor status indicators (`● EN VIVO`) and filter category chips.

## Components

### 1. Telemetry Metric Card (Widget Principal)
- **Container**: Tier 1 surface (`#131E32`), `1px solid #1E293B`, `8px` corner radius, `space-lg` inner padding.
- **Header**: Flex layout. Left: Parameter name in `label-caps` (`#94A3B8`). Right: Sensor status badge or connection heartbeat dot.
- **Data Section**: Live value rendered in `metric-display` (`#F8FAFC`) with unit in `telemetry-unit` appended inline (`#64748B`).
- **Footer**: Embedded 48px height sparkline displaying the trailing 60-minute trend, colored according to the current parameter state (Emerald, Amber, or Rose).

### 2. Status Badges & Chips (Insignias de Estado)
- **Geometry**: Height `22px`, horizontal padding `8px`, corner radius `4px`.
- **Typographic Style**: `label-caps`, uppercase.
- **Color Profiles**:
  - *Óptimo*: Background `#064E3B40`, border `1px solid #05966960`, text `#34D399`.
  - *Moderado / Alerta*: Background `#78350F40`, border `1px solid #D9770660`, text `#FBBF24`.
  - *Crítico / Emergencia*: Background `#88133740`, border `1px solid #E11D4860`, text `#FB7185`.
  - *Inactivo*: Background `#1E293B60`, border `1px solid #47556960`, text `#94A3B8`.

### 3. Action Buttons (Botones de Control)
- **Primary**: Background `#10B981`, hover `#059669`, text `#022C22` (high-contrast deep green), font weight `600`, radius `4px`.
- **Secondary / Ghost**: Background `transparent`, border `1px solid #334155`, hover background `#1E293B`, text `#F8FAFC`.
- **Danger (Parada de Emergencia / Silenciar Alarma)**: Background `#E11D48`, hover `#BE123C`, text `#FFFFFF`.

### 4. Input Fields & Selectors (Entradas y Filtros)
- **Field Box**: Background `#0B1120`, border `1px solid #334155`, focus state `1px solid #10B981` (no halo bloom).
- **Text**: `body-md` in `#F8FAFC`. Placeholder in `#475569`.
- **Labels**: Positioned strictly above the field in `body-sm` (`#94A3B8`), accompanied by Spanish validation feedback below.

### 5. Telemetry Data Tables (Tablas de Sensores)
- **Header**: `#0B1120`, sticky, text styled in `label-caps` with `#64748B`.
- **Rows**: Fixed height `44px`, border bottom `1px solid #1E293B`, zebra striping alternate rows with `#131E32` and `#0E1726`.
- **Hover**: Subtle row highlight with `#1E293B80` and left border indicator (`2px solid #0EA5E9`).
- **Data Alignment**: Text descriptions left-aligned; all numeric telemetry metrics right-aligned with fixed mono spacing.

### 6. Sparklines & Mini Visualizations
- **Baseline**: Hairline stroke (`1.5px`), zero-fill gradient fade (`opacity: 0.15` to `0.0`).
- **Threshold Lines**: Dashed horizontal markers (`1px dashed #F59E0B66`) indicating legal environmental exposure ceilings (e.g., OMS / Normativa Local).